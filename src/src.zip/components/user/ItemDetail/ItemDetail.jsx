export const ItemDetail = ({product}) => {

  console.log(product)
  return (
    <div>
      <h1>hola</h1>
      <h1>hola</h1>
      <h1>hola</h1>
      <h1>hola</h1>
      <p>{product.title}</p>
      <p>{product.id}</p>
      <p>{product.price}</p>
    </div>
  )
}