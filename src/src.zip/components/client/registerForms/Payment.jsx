export const Payment = () => {
  return(
    <div>payment</div>
  )
}