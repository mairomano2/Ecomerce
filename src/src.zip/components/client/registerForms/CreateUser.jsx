export const CreateUser = () => {
  return(
    <div>CreateUser</div>
  )
}