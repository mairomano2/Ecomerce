import "./styles/footer/footer.css"

export const FooterClient = () => {
  return (
    <footer>
      <p className="footer">Footer</p>
    </footer>
  )
}