// import { Client } from "./components/client/Client"
// import { ErrorPage } from "./components/errorPage/ErrorPage"
import { Users } from "./components/user/Users"

function App() {
  return (
    <>
      {/* <Client /> */}
      {/* <ErrorPage /> */}
      <Users />
    </>
  )
}

export default App;
